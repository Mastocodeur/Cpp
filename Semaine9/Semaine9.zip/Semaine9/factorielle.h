/** @file
    Une mini bibliothèque implantant la fonction factorielle
**/

/** La fonction factorielle
 *  @param n un nombre entier positif
 *  @return n!
 **/
int factorielle(int n);
